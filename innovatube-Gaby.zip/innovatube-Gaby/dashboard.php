<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

include 'config/db.php';
include 'config/youtube.php';

$apiKey = 'BIzgSyJm5hwbP t T_gsZrJSmWTuavPjngiekJxf8'; 
$query = 'canciones camila'; 

$videos = getYouTubeVideos($apiKey, $query);

$message = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="header">
        <h1>InnovaTube</h1>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="favorites.php">Ver Favoritos</a>
            <a href="actions/logout.php">Cerrar Sesión</a>
        </nav>
    </div>
    <div class="container">
        <h2>Videos</h2>
        <?php if ($message): ?>
            <p class="message"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        <table>
            <thead>
                <tr>
                    <th>Título</th>
                    <th>URL</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($videos['items'])): ?>
                    <?php foreach($videos['items'] as $video): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($video['snippet']['title']); ?></td>
                        <td><a href="https://www.youtube.com/watch?v=<?php echo htmlspecialchars($video['id']['videoId']); ?>" target="_blank">Ver Video</a></td>
                        <td><a href="actions/favorite.php?video_id=<?php echo htmlspecialchars($video['id']['videoId']); ?>&title=<?php echo urlencode($video['snippet']['title']); ?>">Marcar como Favorito</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">No se encontraron videos.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <footer class="footer">
        &copy; 2024 InnovaTube. Todos los derechos reservados.
    </footer>
</body>
</html>

