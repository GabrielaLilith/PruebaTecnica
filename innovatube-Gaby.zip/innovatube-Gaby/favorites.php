<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

include 'config/db.php';

$user_id = $_SESSION['userid'];
$sql = "SELECT * FROM favorites WHERE user_id = :user_id";
$stmt = $pdo->prepare($sql);
$stmt->execute(['user_id' => $user_id]);
$favorites = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Favoritos</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="header">
        <h1>InnovaTube</h1>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="favorites.php">Ver Favoritos</a>
            <a href="actions/logout.php">Cerrar Sesión</a>
        </nav>
    </div>
    <div class="container">
        <h2>Favoritos</h2>
        <table>
            <thead>
                <tr>
                    <th>Título</th>
                    <th>URL</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($favorites as $favorite): ?>
                <tr>
                    <td><?php echo htmlspecialchars($favorite['title']); ?></td>
                    <td><a href="https://www.youtube.com/watch?v=<?php echo htmlspecialchars($favorite['video_id']); ?>" target="_blank">Ver Video</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <footer class="footer">
        &copy; 2024 InnovaTube. Todos los derechos reservados.
    </footer>
</body>
</html>

