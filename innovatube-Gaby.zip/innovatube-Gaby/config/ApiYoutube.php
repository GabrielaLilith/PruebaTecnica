<?php
function getYouTubeVideos($apiKey, $query) {
    $apiUrl = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q=' . urlencode($query) . '&key=' . $apiKey;
    $response = file_get_contents($apiUrl);
    return json_decode($response, true);
}
?>
